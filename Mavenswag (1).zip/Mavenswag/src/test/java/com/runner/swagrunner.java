package com.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
features="src/main/resources/feature/mavenswag.feature",
plugin = {"pretty","html:test-output","json:json_output/cucmber.json","junit:junit_xml/cucumber.xml"},
tags= {"@TS_01,@TS_02,@TS_03,@TS_04,@TS_05"},
glue = {"com/stepdefinitions"},
monochrome = true
)

public class swagrunner {

}
