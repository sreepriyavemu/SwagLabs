package com.pages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class validmail_page {
	WebDriver driver;
	public void Launch_browser() {
	 System.setProperty("webdriver.chrome.driver", "C:\\kalyan\\chromedriver\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void Launch_App() {
		driver.get("https://saucelabs.com/");
		}
	public void valid_format() {
		WebElement email=driver.findElement(By.id("Email"));
		email.sendKeys("xyzabc@gmail.com");
		email.sendKeys(Keys.ENTER);
	}
	public void assert_mail() throws InterruptedException {
		String message=driver.findElement(By.xpath("//p[@class='supertitle']")).getText();
		Assert.assertNotEquals("Thank you for your interest", message);
		Thread.sleep(2000);
		System.out.println("Thank you for your interest");
		driver.close();

		
	}
}
