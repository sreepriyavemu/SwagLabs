package com.pages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class invalidmail_page {
	WebDriver driver;
	public void Launch_browser() {
	 System.setProperty("webdriver.chrome.driver", "C:\\kalyan\\chromedriver\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void Launch_App() {
		driver.get("https://saucelabs.com/");
		}
	public void Invalid_format() {
		WebElement email1=driver.findElement(By.xpath("//input[@placeholder='Enter Email Address']"));
		email1.sendKeys("bbvbvbvk$gmail.com");
		email1.sendKeys(Keys.ENTER);
	}
	public void assert_Invalidmail() throws InterruptedException {
		String message1=driver.findElement(By.xpath("//div[@class='mktoErrorMsg']")).getText();
		Assert.assertNotEquals("Must be valid email. ", message1);
		Thread.sleep(2000);
		System.out.println(message1);
		driver.close();

		
	}

}
