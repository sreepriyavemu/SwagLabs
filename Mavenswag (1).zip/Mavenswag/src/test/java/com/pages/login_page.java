package com.pages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login_page {
	WebDriver driver;
	public void Launch_browser() {
	 System.setProperty("webdriver.chrome.driver", "C:\\kalyan\\chromedriver\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	  	}
	public void Launch_App() {
	driver.get("https://www.saucedemo.com/");
}
	public void click_login(){
		driver.findElement(By.xpath("//input[@value='LOGIN']")).click();
	}
	public void Assert_login() {
		String actual =	driver.findElement(By.xpath("//div[text()='Products']")).getText();
		Assert.assertEquals("Products", actual);	
		System.out.println(" Actual and expected are same");
		driver.close();
	}
	}