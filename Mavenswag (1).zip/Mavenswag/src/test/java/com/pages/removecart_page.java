package com.pages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class removecart_page {
	WebDriver driver;
	public void Launch_browser() {
	 System.setProperty("webdriver.chrome.driver", "C:\\kalyan\\chromedriver\\chromedriver.exe");
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void Launch_App() {
	driver.get("https://www.saucedemo.com/");
	driver.findElement(By.id("user-name")).sendKeys("standard_user");
	driver.findElement(By.id("password")).sendKeys("secret_sauce");
	driver.findElement(By.xpath("//input[@value='LOGIN']")).click();
}

	public void removecart(){
		driver.findElement(By.xpath("(//button)[3]")).click();
		driver.findElement(By.xpath("(//button)[3]")).click();

}
	public void assert_removecart() throws InterruptedException {
		String num=driver.findElement(By.xpath("(//span)[8]")).getText();
		Assert.assertEquals("0",num);
		System.out.println("Item is removed from cart");
		Thread.sleep(3000);
		driver.close();
	}
	

}
