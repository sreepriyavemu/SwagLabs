package com.steddefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.invalidmail_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Invalidmail extends invalidmail_page{
	WebDriver driver;
	@Given("^LAUNChing THe browser$")
	public void launching_THe_browser() {
		Launch_browser();
		
		
	}

	@When("^LAUNChing THe application$")
	public void launching_THe_application() {
		Launch_App();
			}

	@Then("^enter the Invalid email format  and click on submit button$")
	public void enter_the_Invalid_email_format_and_click_on_submit_button() {
		Invalid_format();
			}

	@Then("^Assert if it is displaying an error message$")
	public void assert_if_it_is_displaying_an_error_message() throws InterruptedException {
		assert_Invalidmail();
	}
}
