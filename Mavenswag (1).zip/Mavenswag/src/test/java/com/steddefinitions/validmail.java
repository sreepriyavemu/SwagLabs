package com.steddefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.validmail_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class validmail extends validmail_page{
	WebDriver driver;
	@Given("^LAUNCHING The browser$")
	public void launching_The_browser() {
		Launch_browser();
		
	
	}

	@When("^LAUNCHING The application$")
	public void launching_The_application() {
		Launch_App();		

	}

	@Then("^enter the valid email format  and click on submit button$")
	public void enter_the_valid_email_format_and_click_on_submit_button() {
	valid_format();
	    //driver.findElement(By.xpath("//button[@class='mktoButton']")).click();
	}

	@Then("^Assert if it is displaying Thank you message$")
	public void assert_if_it_is_displaying_Thank_you_message() throws InterruptedException {
		assert_mail();
		
	}

	
}
