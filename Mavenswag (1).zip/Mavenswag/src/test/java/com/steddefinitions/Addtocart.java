package com.steddefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.Addtocart_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Addtocart extends Addtocart_page {
	WebDriver driver;
	@Given("^LAUNching the browser$")
	public void launching_the_browser5() {
		Launch_browser();
				
	}

	@When("^LAUNching the application$")
	public void launching_the_application5() {
		Launch_App();
			}
	

	@Then("^cLick on ADD TO CART of selected item$")
	public void click_on_ADD_TO_CART_of_selected_item() {
		addcart();
		

	}

	@Then("^Assert if the item is added in the cart$")
	public void assert_if_the_item_is_added_in_the_cart() throws InterruptedException {
		assert_addcart();
		
	}
}
