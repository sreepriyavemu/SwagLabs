package com.steddefinitions;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.login_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class login extends login_page {
WebDriver driver;

@Given("^the user launched the chrome browser$")
public void the_user_launched_the_chrome_browser() throws Throwable {
	Launch_browser();
}

@When("^the user opens Swaglabs homepage$")
public void the_user_opens_Swaglabs_homepage() throws Throwable {
	Launch_App();
}

@When("^the user enters valid username and password$")
public void the_user_enters_valid_username_and_password() throws Throwable {
	driver.findElement(By.id("user-name")).sendKeys("standard_user");
	driver.findElement(By.id("password")).sendKeys("secret_sauce");
}

@When("^click the login button$")
public void click_the_login_button() throws Throwable {
	click_login();
}

@Then("^Assert if the product_label is displayed$")
public void assert_if_the_product_label_is_displayed() throws Throwable {
	Assert_login();
}
}
